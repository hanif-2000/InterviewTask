import React, { useState } from 'react';
import {
  Image,
  Linking,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { loginPageJson } from '../../constants/loginJson';
import { urlPath } from '../../dataUrl/url';
import { styles } from './styles';

const ForgotPasswordScreen = ({navigation}) => {
  const [text, setText] = useState('');

  const handlePress = () => {
    Linking.openURL(urlPath.urLink);
  };

  const handlebtnPress = () => {
    Linking.openURL(urlPath.btnLink);
  };
  return (
    <View style={styles.__sForgotMainContainer}>
      <View>
        <Image
          source={require('../../assesd/imagesremove.png')}
          style={styles.__sMainImage}
        />
      </View>
      <View>
        <Text style={styles.__sForgottext}>{loginPageJson?.topText}</Text>
      </View>
      <View>
        <Text style={styles.__sForgotsecondtext}>
          {loginPageJson?.secondtopText}
          {'\n'}
          <Text>{loginPageJson?.secondText}</Text>
        </Text>
      </View>
      <View>
        <TextInput
          style={styles.__sForgotTextInput}
          placeholder={loginPageJson?.ForgotuserNamePlc}
          value={text}
          onChangeText={setText}
        />
      </View>
      <View>
        <TouchableOpacity style={styles.__sMainTauchable} onPress={handlebtnPress}>
          <Text style={styles.__sSendlinkText}>{loginPageJson?.sendLink}</Text>
        </TouchableOpacity>
      </View>
      <View>
        <TouchableOpacity onPress={handlePress}>
          <Text style={styles.__sResetlink}>{loginPageJson?.resetText}</Text>
        </TouchableOpacity>
      </View>
      <View>
        <View>
          <Text style={styles.__sForgotLine}></Text>
        </View>
        <View>
          <Text style={styles.__sForgotorText}>{loginPageJson?.Ortext}</Text>
        </View>
      </View>
      <View>
        <TouchableOpacity onPress={() => navigation.navigate('SingUp')}>
          <Text style={styles.__sCreateAccountText}>
            {loginPageJson?.accountText}
          </Text>
        </TouchableOpacity>
      </View>
      <View style={{top: 150}}>
        <View>
          <Text style={styles.__sForgotBackLine}></Text>
        </View>
        <View>
          <TouchableOpacity onPress={() => navigation.navigate('LogIn')}>
            <Text style={styles.__sBackBottomText}>
              {loginPageJson?.Backtext}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default ForgotPasswordScreen;

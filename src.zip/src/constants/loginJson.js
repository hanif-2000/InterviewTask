export const loginPageJson = {
  userNamePlc: 'Enter User Name',
  passwordPlc: 'Password',
  forgetText: 'Forgot password?',
  loginText: 'LogIn',
  loginWithFb: 'Log in with Facebook',
  or: 'OR',
  doYouAccount: 'Don’t have an account?',
  signUp: 'Sign Up',
  insta:'Instagram To FaceBook',
  topText: 'Trouble logging in?',
  secondtopText: 'Enter your email, phone, or username and we',
  secondText:'ll send you a link to get back into your account.',
  ForgotuserNamePlc:'Email, Phone, or Username',
  sendLink:'Send Login Link',
  resetText:'Can`t reset your password?',
  Ortext:' OR',
  accountText:'Create new account',
  Backtext:'Back to login'
};



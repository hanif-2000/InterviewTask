import { StyleSheet } from 'react-native';
export const styles = StyleSheet.create({
  __sMainContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems:'center',
    backgroundColor: '#fff',
  },
  __sTextStyle: {
    color: 'black',
    fontSize: 60,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  __sTextInput: {
    borderWidth:1,
   width:300,
   height:45,
   padding:10,
   margin:5,
   borderRadius:10,
   borderColor:'#0000005A'
  },
  __sTextCommon: {
    color:'#3797EF',
    left:'80%'
  },
  __sTextLogin: {
    color: '#fff',
    fontSize: 15,
    backgroundColor: '#3797EF',
    width: 380,
    height: 45,
    textAlign: 'center',
    borderRadius: 7,
    paddingVertical:13
    
  },
  __sMianTouchable: {
    justifyContent: 'center',
    alignItems: 'center',
    margin: 30,
  },
  __sTextcontainer: {
    justifyContent: 'center',
    alignItems: 'center',
     top: 30,

  },
  __scustomText: {
    // // borderWidth: 0.3,
    // // borderColor: '#00000033',
    // // width: '85%',
    // // height: 1,
    // borderWidth:1,
    // borderColor:'red'
  },
 
});

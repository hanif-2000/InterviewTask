import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const TextCustom = ({label, fontSize=14,TextColor="red"}) => {
  return (
    <View>
      <Text style={[styles.switchtext,{fontSize:fontSize,color:TextColor}]}>{label}</Text>
    </View>
  );
};
export default TextCustom;

const styles = StyleSheet.create({
  switchtext: {
    color: '#3797EF',
    fontSize: 18,
    fontWeight: '600',
    margin: 20,
    padding: 10,
  },
});

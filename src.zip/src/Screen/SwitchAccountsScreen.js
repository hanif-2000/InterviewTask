import React, { useState } from 'react';
import {
  Image,
  Linking,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from 'react-native';

const SwitchAccountsScreen = ({navigation}) => {
  const [text, setText] = useState('');
  const [password, setPassword] = useState('');

   
  const handlePress = () => {
    Linking.openURL('https://www.facebook.com/login/');
  };
  return (
    <View style={styles.__sMainContainer}>
      <View>
        <Image
          source={require('../assesd/instagramlogo.png')}
          style={{
            width: '100%',
            height: 80,
            resizeMode: 'contain',
          }}
        />
      </View>

      <View
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          margin: 30,
        }}>
        <TextInput
          style={styles.__sTextInput}
          placeholder="Phone number, username, or email"
          value={text}
          onChangeText={setText}
        />
        <TextInput
          style={styles.__sTextInput}
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry={true}
        />
      </View>

      <View>
        <TouchableOpacity style={styles.__sMianTouchable}>
          <Text style={styles.__sTextLogin}>LogIn</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.__sTextcontainer}>
        <Text style={styles.__sCustomText}></Text>
      </View>
      <View style={{justifyContent: 'center', alignSelf: 'center'}}>
        <Text
          style={{
            textAlign: 'center',
            backgroundColor: '#fff',
            width: 70,
            bottom: 10,
          }}>
          OR
        </Text>
      </View>
      <View>
        <TouchableOpacity  onPress={handlePress}
          style={{flexDirection: 'row', justifyContent: 'center', top: 30}}>
          <View>
            <Image
              source={require('../assesd/icon.png')}
              style={{
                width: 20,
                height: 20,
              }}
            />
          </View>
          <View>
            <Text style={{fontSize: 15, color: '#3797EF', left: 10}}>
              Log in with Facebook
            </Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={{top: 50,}}>
        <TouchableOpacity  onPress={() => navigation.navigate('ForgotPassword')}>
          <Text style={styles.__sTextCommon}>Forgot password?</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.__sBottomText}>
        <Text style={{fontSize: 16}}>Don’t have an account?</Text>
        <TouchableOpacity onPress={() => navigation.navigate('SingUp')}>
          <Text style={{color: '#3797EF', fontSize: 16}}>Sing Up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default SwitchAccountsScreen;

const styles = StyleSheet.create({
  __sMainContainer: {
    flex: 1,
    justifyContent: 'center',
    textAlign: 'center',
    backgroundColor: '#fff',
  },
  __sTextStyle: {
    color: 'black',
    fontSize: 60,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  __sTextInput: {
    borderWidth: 1,
    width: '100%',
    height: 50,
    padding: 10,
    margin: 5,
    borderRadius: 10,
    borderColor: '#0000004A',
  },
  __sTextCommon: {
    textAlign: 'center',
    color: '#00000045',
    fontSize: 15,
    margin: 10,
    
  },
  __sTextLogin: {
    color: '#fff',
    fontSize: 17,
    backgroundColor: '#3797EF',
    width: 350,
    height: 40,
    textAlign: 'center',
    borderRadius: 7,
    paddingVertical: 9,
  },
  __sMianTouchable: {
    justifyContent: 'center',
    alignItems: 'center',
    bottom: 20,
  },
  __sTextcontainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  __sCustomText: {
    borderWidth: 0.3,
    borderColor: '#00000060',
    width:320,
    height: 1,
  },
  __sBottomText: {
    justifyContent: 'center',
    alignItems: 'center',
    margin: 30,
    flexDirection: 'row',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    textAlign: 'center',
    fontSize: 18,
    color: '#000',
    padding: 10,
  },
});

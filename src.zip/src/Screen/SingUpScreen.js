import React, { useState } from 'react';
import {
  Image,
  Linking,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from 'react-native';
import { iconPath } from '../assesd';

const SingUpScreen = () => {
  const [text, setText] = useState('');
  const [name, setName] = useState('');
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');
     
  const handlePress = () => {
    Linking.openURL('https://www.facebook.com/login/');
  };
  return (
    <View style={styles.__sMainContainer}>
      <View>
        <Image
          source={require('../assesd/instagramlogo.png')}
          style={{
            width: '100%',
            height: 70,
            resizeMode: 'contain',
            bottom: 30,
          }}
        />
      </View>
      <View style={{justifyContent: 'center', alignItems: 'center'}}>
        <TouchableOpacity style={styles.__sButton} onPress={handlePress}>
          <View>
            <Image
              source={iconPath.fbLogo}
              style={{
                width: 20,
                height: 20,
              }}
            />
          </View>
          <View>
            <Text style={{fontSize: 15, color: '#fff', left: 10}}>
              Log in with Facebook
            </Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={styles.__sTextcontainer}>
        <Text style={styles.__sCustomText}></Text>
      </View>
      <View style={{justifyContent: 'center', alignSelf: 'center'}}>
        <Text
          style={{
            textAlign: 'center',
            backgroundColor: '#fff',
            width: 70,
            height: 40,
            paddingVertical: 9,
            top: 10,
            fontWeight: '700',
          }}>
          OR
        </Text>
      </View>
      <View
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          margin: 30,
        }}>
        <TextInput
          style={styles.__sTextInput}
          placeholder="Mobile Number or Email"
          value={text}
          onChangeText={setText}
        />
        <TextInput
          style={styles.__sTextInput}
          placeholder="Full Name"
          value={name}
          onChangeText={setName}
        />
        <TextInput
          style={styles.__sTextInput}
          placeholder="Username"
          value={user}
          onChangeText={setUser}
        />
        <TextInput
          style={styles.__sTextInput}
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry={true}
        />
      </View>

      <View>
        <TouchableOpacity style={styles.__sMianTouchable}>
          <Text style={styles.__sTextLogin}>Sing Up</Text>
        </TouchableOpacity>
      </View>
      <View style={{justifyContent: 'center', alignItems: 'center',}}>
        <Text style={styles.__sBottomText}>
          By signing up, you agree to our{'\n'}
          <Text style={styles.__sBoldText}>
            Terms, Data Policy and Cookies{'\n'}
          </Text>
          <Text style={styles.__sCenterText}>Policy</Text>
        </Text>
      </View>
    </View>
  );
};

export default SingUpScreen;

const styles = StyleSheet.create({
  __sMainContainer: {
    flex: 1,
    justifyContent: 'center',
    textAlign: 'center',
    backgroundColor: '#fff',
  },
  __sTextStyle: {
    color: 'black',
    fontSize: 60,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  __sTextInput: {
    borderWidth: 1,
    width: '100%',
    height: 40,
    padding: 10,
    margin: 5,
    borderRadius: 10,
    borderColor: '#0000001A',
  },

  __sTextLogin: {
    color: '#fff',
    fontSize: 15,
    backgroundColor: '#3797EF',
    width: 310,
    height: 30,
    textAlign: 'center',
    borderRadius: 4,
    paddingVertical: 3,
  },
  __sMianTouchable: {
    justifyContent: 'center',
    alignItems: 'center',
    bottom: 20,
  },
  __sTextcontainer: {
    justifyContent: 'center',
    alignItems: 'center',
    top: 30,
  },
  __sCustomText: {
    borderWidth: 0.3,
    borderColor: '#00000033',
    width: '75%',
    height: 1,
  },
  __sButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: '#3797EF',
    width: '75%',
    height: 35,
    borderRadius: 5,
    alignItems: 'center',
  },
  __sBottomText: {
    fontSize: 16,
    color: '#000',
    textAlign: 'center',
    fontSize:15,
    color:'#C0C0C0'
  },
  __sBoldText: {
    fontWeight: '500',
    color: '#A9A9A9',
  },
  __sCenterText: {
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#A9A9A9',
  },
});

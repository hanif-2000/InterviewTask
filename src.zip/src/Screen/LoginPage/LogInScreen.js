import React, { useState } from 'react';
import { Image, Linking, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { loginPageJson } from '../../constants/loginJson';
import CustomButton from '../../CustomComponent/CustomButton';
import { styles } from './styles';

const LogInScreen = ({navigation}) => {
  const [text, setText] = useState('');
  const [password, setPassword] = useState('');

 
  const handlePress = () => {
    Linking.openURL('https://www.facebook.com/login/');
  };
  return (
    <View style={styles.__sMainContainer}>
      <View>
        <Image
          source={require('../../assesd/instagramlogo.png')}
          style={{
            width: 500,
            height: 80,
            resizeMode: 'contain',
          }}
        />
      </View>

      <View
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          margin: 30,
        }}>
        <TextInput
          style={styles.__sTextInput}
          placeholder={loginPageJson?.userNamePlc}
          value={text}
          onChangeText={setText}
        />
        <TextInput
          style={styles.__sTextInput}
          placeholder={loginPageJson?.passwordPlc}
          value={password}
          onChangeText={setPassword}
          secureTextEntry={true}
        />
      </View>
      <View>
        <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')}>
          <Text style={styles.__sTextCommon}>{loginPageJson?.forgetText}</Text>
        </TouchableOpacity>
      </View>

      <View>
        <CustomButton
        
          textStyle={{
            fontSize: 15,
            textAlign: 'center',
            paddingVertical: 13,
          }}
          label={loginPageJson?.loginText}
          navigation={navigation}
        />
      </View>
      <View>
        <TouchableOpacity onPress={handlePress}
          style={{flexDirection: 'row', justifyContent: 'center'}}>
          <View>
            <Image
              source={require('../../assesd/icon.png')}
              style={{
                width: 20,
                height: 20,
              }}
            />
          </View>
          <View>
            <Text style={{fontSize: 15, color: '#3797EF', left: 10}}>
              Log in with Facebook
            </Text>
          </View>
        </TouchableOpacity>
      </View>
      {/* <View style={styles.__sTextcontainer}>
        <Text style={{
           borderWidth: 0.3,
     borderColor: '#00000033',
     width: '85%',
     height: 1,
     
        }}></Text>
      </View> */}
      <View>
        <Text
          style={{
            borderWidth: 0.3,
            borderColor: 'bold',
            height: 1,
            width: 300,
            top: 30,
          }}></Text>
      </View>
      <View style={{justifyContent: 'center', alignSelf: 'center'}}>
        <Text
          style={{
            textAlign: 'center',
            backgroundColor: '#fff',
            width: 100,
            height: 40,
            paddingVertical: 9,
            top: 10,
          }}>
          OR
        </Text>
      </View>
      <View
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          margin: 30,
          flexDirection: 'row',
        }}>
        <Text style={{fontSize: 16}}>Don’t have an account?</Text>
        <TouchableOpacity onPress={() => navigation.navigate('SingUp')}>
          <Text style={{color: '#3797EF', fontSize: 16}}>Sing Up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default LogInScreen;

import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

const CustomButton = ({ label, onPressBtn, touchStyle, textStyle, navigation, __schangeImage }) => {
  return (
    <View>
      <TouchableOpacity
     
        onPress={() => {
          if (onPressBtn) onPressBtn(); 
          if (navigation) navigation.navigate('HomePage');
        }}
        style={[styles.__sMianTouchable, touchStyle]}>
        <Text style={[styles.__sTextLogin, textStyle]}>{label}</Text>
      </TouchableOpacity>
      {/* <View>
        <Image style={[styles.__sHomepageImage, __schangeImage]}/>
      </View> */}
    </View>
  ) 
};

export default CustomButton;

const styles = StyleSheet.create({
  __sMianTouchable: {
    justifyContent: 'center',
    alignItems: 'center',
    margin: 30,
  },
  __sTextcontainer: {
    justifyContent: 'center',
    alignItems: 'center',
    top: 50,
    padding: 30,
  },
  __sTextLogin: {
    color: '#fff',
    fontSize: 17,
    backgroundColor: '#3797EF',
    width: 320,
    height: 45,
    textAlign: 'center',
    borderRadius: 7,
    paddingVertical: 15,
  },
});

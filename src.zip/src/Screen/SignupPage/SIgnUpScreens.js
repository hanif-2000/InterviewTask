import React, { useState } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';

const SIgnUpScreens = () => {
  const listArray = useState([1, 2, 3, 4, 5]);

  const renderItemList = ({item, index}) => {
    console.log('-----INDEx ------------>>>>>>>', index);
    return (
      <View style={{flex: 1}}>
        {index == 0 ? (
          <View style={{backgroundColor: 'red', padding: 20}}>
            <Text
              style={{
                color: '#fff',
              }}>
              YOUR STORY
            </Text>
          </View>
        ) : null}
        <View style={{backgroundColor: 'yellow', padding: 20}}>
          <Text
            style={{
              color: '#000',
            }}>
            DUSERIIIIII STORY
          </Text>
        </View>
      </View>
    );
  };

  return (
    <View style={{flex: 1}}>
      <FlatList horizontal data={listArray} renderItem={renderItemList} />
    </View>
  );
};

export default SIgnUpScreens;

const styles = StyleSheet.create({});

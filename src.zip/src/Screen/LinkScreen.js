import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const LinkScreen = () => {
  return (
    <View>
      <Text>LoginlinkScreen</Text>
    </View>
  )
}

export default LinkScreen

const styles = StyleSheet.create({})
import React from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

const HomeScreen = ({navigation}) => {
  return (
    <View style={styles.__sMaincontainer}>
      <View>
    <Image source={require('../assesd/instagramlogo.png')}
       style={{width:'100%',height:80,resizeMode:"contain"}}
    />
      </View>
      <View style={styles.__sMainView}>
        <Image source={require('../assesd/oval.png')} style={styles.__sMainImage} />
      </View>
      <View>
        <Text style={styles.__sTextStyle}>jacob_w</Text>
      </View>
      <View>
        <TouchableOpacity style={styles.__sMianTouchable}   onPress={() => navigation.navigate('LogIn')} >
          <Text style={styles.__sTextLogin}>LogIn</Text>
        </TouchableOpacity>
      </View>
      <View>
        <TouchableOpacity style={styles.switch}  onPress={() => navigation.navigate('SwitchAccounts')}>
          <Text style={styles.switchtext}>Switch accounts</Text>
        </TouchableOpacity>
      </View>
      <View style={{top:120}}>
        <Text style={{
          borderWidth:0.7,
          height:1,
          borderColor:'#c0c0c0'
          }}>
          </Text>
          <View style={{justifyContent:"center",alignItems:"center",margin:10,flexDirection:'row'}}>
        
        <Text>Don’t have an account?</Text>
        <TouchableOpacity onPress={() => navigation.navigate('SingUp')}>
          <Text style={{color:'#000'}}>Sing Up</Text>
        </TouchableOpacity>
     
      
      </View>
      </View>
    
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
 __sMaincontainer: {
    flex: 1,
    justifyContent: 'center',
    textAlign: 'center',
  },
  
  __sMainImage: {
    width: 100,
    height: 100,
    margin: 40,
  },
  __sMainView: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  __sTextStyle: {
    justifyContent: 'center',
    textAlign: 'center',
    bottom: 30,
    color: '#000',
    fontWeight: 'bold',
  },
  __sTextLogin: {
    color: '#fff',
    fontSize: 17,
    backgroundColor: '#3797EF',
    width: 330,
    height: 45,
    textAlign: 'center',
    borderRadius: 7,
    paddingVertical: 10,
  },
  __sMianTouchable: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  switchtext: {
    color: '#3797EF',
    fontSize: 18,
    fontWeight: '600',
    margin: 20,
    padding: 10,
  },
  switch: {
    justifyContent: 'center',
    alignItems: 'center',
  },
});

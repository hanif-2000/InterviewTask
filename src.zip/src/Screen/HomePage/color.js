import { } from 'react-native';
export const colorPath={
    mixcolor:['#FBAA47', '#D91A46', '#A60F93'],
    mxcolor:['#E20337','#C60188', '#7700C3']
}
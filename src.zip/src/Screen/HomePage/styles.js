import { StyleSheet } from 'react-native';
export const styles = StyleSheet.create({
  __sHomepageContainer: {
    flex: 1,
  },
  __sMainContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 30,
  },
  __sHomepageImage: {
    width: 50,
    height: 30,
    resizeMode: 'contain',
  },
  __sHomepageMainView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    top: 10,
    width: 400,
  },
  __sHomepageImage1: {
    width: 80,
    height: 30,
    resizeMode: 'contain',
    left: 40,
  },
  __sHomepageInstaImage: {
    width: 150,
    height: 30,
    resizeMode: 'contain',
    left: 30,
    top: 5,
  },
  __sHomepageText: {
    borderWidth: 0.3,
    height: 0.3,
    borderColor: '#A6A6AA',
    width: '100%',
    top: 30,
  },
  __sgradientBorder: {
    borderRadius: 50,
    width: 85,
    height: 85,
    justifyContent: 'center',
    alignItems: 'center',
    margin: 10,
  },
  __sinnerCircle: {
    width: 76,
    height: 76,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#fff',
    borderWidth: 3,
  },

  __sotherStories: {
    padding: 20,
    borderRadius: 50,
    width: 76,
    height: 76,
    margin: 15,
    borderColor: '#fff',
    borderWidth: 3,
  },
  __sotherStoryText: {
    color: '#000',
  },
  __sinnerText: {
    color: 'black',
    textAlign: 'center',
    fontSize: 14,
    bottom: 10,
  },
  __slineText: {
    borderWidth: 0.3,
    height: 0.3,
    borderColor: '#A6A6AA',
    width: '100%',
  },
  __sHeader:{
    flexDirection: 'row',
    justifyContent: 'space-between',
  }
});

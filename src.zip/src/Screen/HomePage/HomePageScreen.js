import React, { useState } from 'react';
import { FlatList, Image, Text, View } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { iconPath } from '../../assesd';
import { styles } from '../HomePage/styles';
import { colorPath } from './color';

const HomePageScreen = () => {
  const [listArray, setListArray] = useState([
    {
      id: 1,
      userName: 'MR,king__7706',
      userProfile: iconPath.innerovlogo,
      userNameColor: 'green',
      userStatus: 'Live',
    },
    {
      id: 2,
      userName: 'I_AM_KHAN',
      userProfile: iconPath.innerlogo,
      userNameColor: 'red',
      userStatus: null,
    },
    {
      id: 3,
      userName: 'Azhar0012',
      userProfile: iconPath.igLogo,
      userNameColor: 'blue',
      userStatus: 'Live',
    },
  ]);
  const renderItemList = ({item, index}) => {
    console.log('-----item ------------>>>>>>>', item);
    return (
      <View style={styles.__sMainContainer}>
        {index == 0 ? (
          <View>
            <LinearGradient
              colors={colorPath.mixcolor}
              style={styles.__sgradientBorder}>
              <View style={styles.__sinnerCircle}>
                <Image
                  source={iconPath.innerlogo}
                  style={styles.__sinnerCircle}
                />
              </View>
            </LinearGradient>
            <View>
              <Text style={styles.__sinnerText}>Your Story</Text>
            </View>
          </View>
        ) : null}
        <View>
          <LinearGradient
            colors={colorPath.mxcolor}
            style={styles.__sgradientBorder}>
            <View style={styles.__sinnerCircle}>
              <Image
                source={item?.userProfile}
                style={styles.__sotherStories}
              />
            </View>
          </LinearGradient>
          <View>
            <Text style={[styles.__sinnerText, {color: item?.userNameColor}]}>
              {item?.userName}
            </Text>
          </View>
          {item?.userStatus == 'Live' ? (
            <View
              style={{
                height: 40,
                width: 60,
                justifyContent: 'center',
                alignItem: 'center',
                alignSelf: 'center',
                borderRadius: 20,
            
              
              
              }}>
              <Text
                style={[
                  styles.__sinnerText,
                  {color: '#fff', textAlign: 'center'},
                ]}>
                {item?.userStatus}
              </Text>
            </View>
          ) : null}
        </View>
      </View>
    );
  };

  return (
    <View style={styles.__sHomepageContainer}>
      <View style={styles.__sHomepageMainView}>
        <Image source={iconPath.cmLogo} style={styles.__sHomepageImage} />
        <Image
          source={iconPath.instalogo}
          style={styles.__sHomepageInstaImage}
        />
        <Image source={iconPath.igLogo} style={styles.__sHomepageImage1} />
        <Image source={iconPath.msglogo} style={styles.__sHomepageImage} />
      </View>
      <View>
        <Text style={styles.__sHomepageText}></Text>
      </View>

      <View>
        <FlatList
          horizontal={true}
          data={listArray}
          renderItem={renderItemList}
          ListEmptyComponent={() => (
            <View style={{width: 200, height: 200, backgroundColor: 'red'}}>
              <Text style={{}}>No Data Found</Text>
            </View>
          )}
        />
      </View>
      <View>
        <Text style={styles.__slineText}></Text>
      </View>
      <View style={styles.__sHeader}></View>
    </View>
  );
};

export default HomePageScreen;

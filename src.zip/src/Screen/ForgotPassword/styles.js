import { StyleSheet } from 'react-native';
export const styles = StyleSheet.create({
  __sForgotMainContainer: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  __sMainImage: {
    width: 200,
    height: 200,
    resizeMode: 'contain',
  },
  __sForgottext: {
    fontSize: 18,
    color: 'black',
    bottom: 30,
  },
  __sForgotsecondtext: {
    textAlign: 'center',
  },
  __sForgotTextInput: {
    borderWidth: 1,
    width: 300,
    height: 45,
    padding: 10,
    margin: 10,
    borderRadius: 10,
    borderColor: '#0000005A',
  },
  __sMainTauchable: {
    backgroundColor: '#3797EF',
    justifyContain: 'center',
    alignItem: 'center',
    width: 300,
    height: 38,
    borderRadius: 10,
  },
  __sSendlinkText: {
    textAlign: 'center',
    color: '#fff',
    paddingVertical: 8,
  },
  __sResetlink: {
    color: 'blue',
    margin: 10,
    fontSize: 13,
    fontWeight: '300',
  },
  __sForgotLine: {
    borderWidth: 0.3,
    borderColor: 'bold',
    height: 0.2,
    width: 300,
    top: 30,
  },
  __sForgotorText: {
    textAlign: 'center',
    backgroundColor: '#fff',
    width: 75,
    height: 40,
    paddingVertical: 9,
    top: 10,
    justifyContent: 'center',
    alignSelf: 'center',
  },
  __sCreateAccountText: {
    color: 'black',
    top: 30,
    fontWeight: '600',
  },
  __sForgotBackLine: {
    borderWidth: 0.3,
    borderColor: 'bold',
    height: 0.2,
    width: 400,
  },
  __sBackBottomText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: '600',
    margin: 15,
  },
});

export const iconPath={
    fbLogo:require('../assesd/facebook.png'),
    cmLogo:require('../assesd/Cameraicon.png'),
    igLogo:require('../assesd/IGTV.png'),
    instalogo:require('../assesd/instagramlogo.png'),
    msglogo:require('../assesd/Messanger.png'),
    innerlogo:require('../assesd/Inneroval.png'),
    innerovlogo:require('../assesd/InnerOval(1).png'),
    innerov1logo:require('../assesd/InnerOval(2).png')

}